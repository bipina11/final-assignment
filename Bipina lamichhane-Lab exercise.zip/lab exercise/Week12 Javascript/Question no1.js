/*
javascript exercises 2



Write a javascript program to show date and time in this format: 2020-08-20 10:12:30
*/

const year = new Date().getFullYear();
const month = new Date().getMonth();
const day = new Date().getDate();
const hours = new Date().getHours();
const minutes = new Date().getMinutes();
const seconds = new Date().getSeconds();
console.log(`${year}-${month}-${day} ${hours}:${minutes}:${seconds}`);
