// 1) Write a program in Javascript to create variables to store numeric, float, string and Boolean values and show them in page with document.write() function.

//   see in html

// 2) Write a program to input two data values for Your Name and Student Id in prompt dialog boxes and show them in alert dialog box.

/* 3) 	WAP to show the use if …. Else if …. else for following conditions:
⦁	For marks > = 80 and marks <=100, show Distinction
⦁	For marks >=60 and marks < 80, show First Division
⦁	For marks >=50 and marks < 60, show Second Division
⦁	For marks >=40 and marks <50, show Third Division
⦁	For marks < 40, show Fail

see in html
 */
/*  4)	WAP to get number input with prompt dialog dox and show the Day using switch case
⦁	For Case 1, show Sunday
⦁	For Case 2, show Monday
⦁	For Case 3, show Tuesday
⦁	For Case 4, show Wednesday
⦁	For Case 5, show Thursday
⦁	For Case 6, show Friday
⦁	For Case 7, show Saturday
⦁	For default, show Invalid

see in html
 */
/*
5)	WAP in javascript using for loop to display 4 images with image name as 1.jpg, 2.jpg, 3.jpg and 4.jpg.
see in html
*/
/* 6)	WAP to display multiplication number of 5 as follows:
5 * 1 = 5
5 * 2 = 10
5 * 3 = 15
……………
…………….
5 * 10 = 50
 */
/* 7) WAP in javascript using loop to display following table layout and with alternate background color on data rows
 
 */


/*8)	Write a simple JavaScript program to join all elements of the following array into a string. Sample array : myColor = ["Red", "Green", "White", "Black"];

*/
let myColor = ["Red", "Green", "White", "Black"];
let res = myColor.toString()
console.log(res)
let a = myColor.join()
console.log(a)
console.log(myColor.join('+'))

/*9) ⦁	Write a JavaScript program to compute the sum and product of an array of integers.
 */

 let arr = [1,2,3,4,5,6,7,8,9]
 let s = 0
 let c = 1
 const b = arr.forEach((el)=>{
    s += el
    
    console.log(s)
 })
 const d = arr.forEach((el)=>{
    c *= el
    
    console.log(c)
 })

 /*
 10)	Write a Javascript function to calculate area of rectangle which accepts two parameters – length and breadth.
 */

const areaOfRectangle = (length, breadth)=>{
    return length * breadth
}
console.log(areaOfRectangle(4, 3))

