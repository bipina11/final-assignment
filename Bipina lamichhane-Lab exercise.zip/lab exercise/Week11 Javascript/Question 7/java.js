let data = [
  { SN: 1, name: "Name 1", image: "1.jpg" },
  { SN: 2, name: "Name 2", image: "2.jpg" },
  { SN: 3, name: "Name 3", image: "3.jpg" },
  { SN: 4, name: "Name 4", image: "4.jpg" },
];

const InTableForm = (data) => {
  const tableBody = document.getElementById("tableData");
  let innerHtml = "";
  data.forEach((element, index) => {
    if (index % 2 == 0) {
      innerHtml += `<tr style=" background-color:#dddddd"><td>${element.SN}</td><td>${element.name}</td><td>${element.image}`;
    } else {
      innerHtml += `<tr><td>${element.SN}</td><td>${element.name}</td><td>${element.image}`;
    }
  });

  tableBody.innerHTML = innerHtml;
};
InTableForm(data);
